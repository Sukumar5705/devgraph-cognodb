import { Router } from 'express';
import technologyController from '../controllers/technology.controller.js';

const router = Router();

router.get('/:name', technologyController.getTechnology);
router.get('/:name/community', technologyController.getCommunity);

export default router;
