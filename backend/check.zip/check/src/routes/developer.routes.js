import { Router } from 'express';
import developerController from '../controllers/developer.controller.js';
import connectionController from '../controllers/connection.controller.js';

const router = Router();

router.get('/:username', developerController.getDeveloper);
router.get('/:username/network', developerController.getNetwork);
router.get('/:username/connections', connectionController.getConnectedDevelopers);

export default router;
