import connectionRepository from '../repositories/connection.repository.js';
import { parsePath } from '../utils/normalize.js';

class ConnectionService {
  async getConnectedDevelopers(username, limit) {
    if (!username) {
      throw { statusCode: 400, message: 'Username is required' };
    }
    return await connectionRepository.getConnectedDevelopers(username, limit);
  }

  async getDeveloperPath(fromUsername, toUsername) {
    if (!fromUsername || !toUsername) {
      throw { statusCode: 400, message: 'Both "from" and "to" developer usernames are required' };
    }
    const path = await connectionRepository.getDeveloperToDevPath(fromUsername, toUsername);
    if (!path) {
      return { found: false, path: [], relationships: [] };
    }
    return parsePath(path);
  }
}

export default new ConnectionService();
