import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
});

export const getConnectionPath = async (fromUsername: string, toTechnology: string) => {
  const { data } = await api.get(`/paths?from=${fromUsername}&to=${toTechnology}`);
  return data;
};
