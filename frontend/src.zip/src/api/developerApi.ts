import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
});

export const getDeveloper = async (username: string) => {
  const { data } = await api.get(`/developers/${username}`);
  return data.data;
};

export const getDeveloperNetwork = async (username: string) => {
  const { data } = await api.get(`/developers/${username}/network`);
  return data.data;
};

export const getRelatedDevelopers = async (username: string, limit = 10) => {
  const { data } = await api.get(`/developers/${username}/connections?limit=${limit}`);
  return data.data;
};
