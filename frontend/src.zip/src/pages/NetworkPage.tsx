import { useEffect, useState, useRef, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { getDeveloperNetwork, getRelatedDevelopers } from "../api/developerApi";
import ForceGraph2D from "react-force-graph-2d";
import { ArrowLeft } from "lucide-react";

export function NetworkPage() {
  const { username } = useParams<{ username: string }>();
  const [network, setNetwork] = useState<any>({ nodes: [], edges: [] });
  const [related, setRelated] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const fgRef = useRef<any>(null);

  useEffect(() => {
    if (username) {
      Promise.all([
        getDeveloperNetwork(username),
        getRelatedDevelopers(username)
      ])
        .then(([networkData, relatedData]) => {
          setNetwork({
            nodes: networkData.nodes,
            links: networkData.edges.map((e: any) => ({
              source: e.source,
              target: e.target,
              label: e.relationship
            }))
          });
          setRelated(relatedData);
        })
        .finally(() => setLoading(false));
    }
  }, [username]);

  const getNodeColor = (type: string) => {
    switch (type) {
      case "Developer": return "#2563eb"; // blue-600
      case "Repository": return "#4b5563"; // gray-600
      case "Technology": return "#10b981"; // emerald-500
      case "Topic": return "#8b5cf6"; // violet-500
      case "Organization": return "#f59e0b"; // amber-500
      default: return "#9ca3af";
    }
  };

  const drawNode = useCallback((node: any, ctx: CanvasRenderingContext2D, globalScale: number) => {
    const label = node.label || "";
    const fontSize = 12 / globalScale;
    ctx.font = `${fontSize}px Sans-Serif`;
    const textWidth = ctx.measureText(label).width;
    const bckgDimensions = [textWidth, fontSize].map(n => n + fontSize * 0.2); // some padding

    ctx.fillStyle = getNodeColor(node.type);
    ctx.beginPath();
    ctx.arc(node.x, node.y, 5, 0, 2 * Math.PI, false);
    ctx.fill();

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#1f2937';
    ctx.fillText(label, node.x, node.y + 8);
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-64px)] flex flex-col md:flex-row overflow-hidden bg-gray-50">
      <div className="flex-1 relative h-full">
        <div className="absolute top-4 left-4 z-10">
          <Link to={`/${username}`} className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg shadow-sm font-medium hover:bg-gray-50 border border-gray-200">
            <ArrowLeft size={16} /> Back to Profile
          </Link>
        </div>
        <ForceGraph2D
          ref={fgRef}
          graphData={network}
          nodeLabel="label"
          nodeColor={(node: any) => getNodeColor(node.type)}
          nodeCanvasObject={drawNode}
          linkColor={() => "#d1d5db"} // gray-300
          linkDirectionalArrowLength={3.5}
          linkDirectionalArrowRelPos={1}
          onEngineStop={() => fgRef.current?.zoomToFit(400, 50)}
        />

        <div className="absolute bottom-4 left-4 z-10 bg-white p-4 rounded-lg shadow-sm border border-gray-200 text-sm">
          <h3 className="font-bold mb-2">Legend</h3>
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-blue-600"></div> Developer</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-gray-600"></div> Repository</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-emerald-500"></div> Technology</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-violet-500"></div> Topic</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-amber-500"></div> Organization</div>
          </div>
        </div>
      </div>

      <div className="w-full md:w-80 bg-white border-l border-gray-200 p-6 overflow-y-auto">
        <h2 className="text-xl font-bold mb-6">Related Developers</h2>
        <p className="text-sm text-gray-500 mb-6">Developers connected through shared technologies.</p>

        <div className="flex flex-col gap-4">
          {related.length === 0 ? (
            <p className="text-gray-500 text-sm italic">No related developers found.</p>
          ) : (
            related.map((dev: any) => {
              const sharedTechs = Array.isArray(dev.sharedTechnologies) ? dev.sharedTechnologies : [];
              return (
                <div key={dev.username} className="p-4 border border-gray-100 bg-gray-50 rounded-xl">
                  <Link to={`/${dev.username}`} className="font-bold text-blue-600 hover:underline block mb-1">
                    @{dev.username}
                  </Link>
                  <div className="text-sm text-gray-600 mb-2">
                    <span className="font-medium text-gray-900">{dev.totalConnections || dev.sharedCount || 0}</span> shared connections
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {sharedTechs.slice(0, 3).map((tech: string) => (
                      <span key={tech} className="text-xs px-2 py-0.5 bg-white border border-gray-200 rounded text-gray-600">
                        {tech}
                      </span>
                    ))}
                    {sharedTechs.length > 3 && (
                      <span className="text-xs px-2 py-0.5 text-gray-500">+{sharedTechs.length - 3}</span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
