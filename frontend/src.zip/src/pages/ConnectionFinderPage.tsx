import { useState } from "react";
import { getConnectionPath } from "../api/graphApi";
import { Search, ArrowRight } from "lucide-react";

export function ConnectionFinderPage() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [pathData, setPathData] = useState<any>(null);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!from || !to) return;
    
    setLoading(true);
    setPathData(null);
    try {
      const res = await getConnectionPath(from, to);
      if (res.data && res.data.found) {
        setPathData(res.data);
      }
      setMessage(res.message);
    } catch (err: any) {
      setMessage("Error finding connection.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 mt-12">
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
        <h1 className="text-3xl font-bold mb-2">Connection Finder</h1>
        <p className="text-gray-500 mb-8">Find the shortest graph path between a Developer and a Technology.</p>
        
        <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4 items-end mb-8">
          <div className="flex-1 w-full">
            <label className="block text-sm font-medium text-gray-700 mb-1">From Developer</label>
            <input
              type="text"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              placeholder="e.g. octocat"
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div className="hidden md:block pb-3 text-gray-400">
            <ArrowRight />
          </div>
          <div className="flex-1 w-full">
            <label className="block text-sm font-medium text-gray-700 mb-1">To Technology</label>
            <input
              type="text"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              placeholder="e.g. React"
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full md:w-auto px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 flex items-center justify-center gap-2 disabled:opacity-70"
          >
            {loading ? "Searching..." : <><Search size={18} /> Find Path</>}
          </button>
        </form>
        
        {message && (
          <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 mb-6 font-medium text-gray-700">
            {message}
          </div>
        )}
        
        {pathData && pathData.found && pathData.path.length > 0 && (
          <div className="border border-gray-200 rounded-xl p-6 bg-gray-50 overflow-x-auto">
            <div className="flex items-center gap-4 min-w-max">
              {/* Render the first node */}
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center border-2 border-blue-500 text-blue-700 font-bold shadow-sm">
                  {pathData.path[0].type.charAt(0)}
                </div>
                <span className="mt-2 text-sm font-medium max-w-[120px] text-center truncate">{pathData.path[0].label}</span>
              </div>
              
              {/* Render the path segments */}
              {pathData.relationships.map((relationship: string, i: number) => {
                const endNode = pathData.path[i + 1];
                const isTech = endNode.type === 'Technology';
                const isRepo = endNode.type === 'Repository';
                return (
                  <div key={i} className="flex items-center gap-4">
                    <div className="flex flex-col items-center">
                      <span className="text-xs text-gray-400 uppercase tracking-wider mb-1">
                        {relationship}
                      </span>
                      <div className="w-16 h-0.5 bg-gray-300"></div>
                      <ArrowRight size={14} className="text-gray-400 mt-1" />
                    </div>
                    <div className="flex flex-col items-center">
                      <div className={`w-16 h-16 rounded-full flex items-center justify-center border-2 shadow-sm ${
                        isTech ? 'bg-emerald-100 border-emerald-500 text-emerald-700' : 
                        isRepo ? 'bg-gray-200 border-gray-500 text-gray-700' : 'bg-gray-100'
                      }`}>
                        <span className="font-bold">{endNode.type.charAt(0)}</span>
                      </div>
                      <span className="mt-2 text-sm font-medium max-w-[120px] text-center truncate">
                        {endNode.label}
                      </span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
