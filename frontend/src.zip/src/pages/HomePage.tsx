import { useState } from "react";
import { useNavigate } from "react-router-dom";

export function HomePage() {
  const [username, setUsername] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      navigate(`/${username.trim()}`);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-4">
      <div className="max-w-2xl text-center">
        <h1 className="text-5xl font-extrabold tracking-tight text-gray-900 mb-4">
          Dev<span className="text-blue-600">Graph</span>
        </h1>
        <p className="text-xl text-gray-600 mb-10">
          Explore how developers, repositories, and technologies are connected.
        </p>
        
        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto w-full">
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="GitHub username (e.g. octocat)"
            className="flex-1 px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg shadow-sm"
            required
          />
          <button
            type="submit"
            className="px-8 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors shadow-sm text-lg"
          >
            Search
          </button>
        </form>
      </div>
    </div>
  );
}
