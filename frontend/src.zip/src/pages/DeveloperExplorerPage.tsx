import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getDeveloper } from "../api/developerApi";
import { Building2, MapPin, Users, BookOpen } from "lucide-react";

export function DeveloperExplorerPage() {
  const { username } = useParams<{ username: string }>();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (username) {
      setLoading(true);
      getDeveloper(username)
        .then(setData)
        .catch(err => {
          console.error(err);
          setError(err.response?.data?.error?.message || "Developer not found in graph.");
        })
        .finally(() => setLoading(false));
    }
  }, [username]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-2xl mx-auto mt-12 p-6 bg-red-50 text-red-600 rounded-lg text-center">
        <h2 className="text-xl font-semibold mb-2">Error</h2>
        <p>{error}</p>
        <Link to="/" className="inline-block mt-4 text-blue-600 hover:underline">Return Home</Link>
      </div>
    );
  }

  const { developer, repositories, technologies, topics, organizations } = data;

  return (
    <div className="max-w-4xl mx-auto px-4 mt-8">
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-8 items-start">
        <img 
          src={developer.avatarUrl || `https://github.com/${developer.username}.png`} 
          alt={developer.username} 
          className="w-32 h-32 rounded-full border border-gray-200 shadow-sm"
        />
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-gray-900">{developer.name || developer.username}</h1>
          <p className="text-lg text-gray-500 mb-4">@{developer.username}</p>
          
          {developer.bio && <p className="text-gray-700 mb-6">{developer.bio}</p>}
          
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm text-gray-600 mb-8">
            <div className="flex items-center gap-2"><Users size={16}/> {developer.followers} followers</div>
            <div className="flex items-center gap-2"><BookOpen size={16}/> {developer.publicRepos} public repos</div>
            {developer.location && <div className="flex items-center gap-2"><MapPin size={16}/> {developer.location}</div>}
            {developer.company && <div className="flex items-center gap-2"><Building2 size={16}/> {developer.company}</div>}
          </div>
          
          <div className="flex gap-4">
            <Link 
              to={`/${username}/network`}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Explore Network
            </Link>
          </div>
        </div>
      </div>
      
      <div className="grid md:grid-cols-2 gap-6 mt-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold mb-4">Top Technologies</h2>
          <div className="flex flex-wrap gap-2">
            {technologies.length === 0 ? <p className="text-gray-500 text-sm">No technologies found.</p> :
             technologies.slice(0, 20).map((t: any) => (
              <span key={t.normalizedName} className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-medium border border-blue-100">
                {t.name}
              </span>
            ))}
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold mb-4">Top Topics</h2>
          <div className="flex flex-wrap gap-2">
            {topics.length === 0 ? <p className="text-gray-500 text-sm">No topics found.</p> : 
             topics.slice(0, 20).map((t: any) => (
              <span key={t.normalizedName} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium">
                {t.name}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
