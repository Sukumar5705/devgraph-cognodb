import { createBrowserRouter } from "react-router-dom"
import { AppLayout } from "../layouts/AppLayout"
import { HomePage } from "../pages/HomePage"
import { DeveloperExplorerPage } from "../pages/DeveloperExplorerPage"
import { NetworkPage } from "../pages/NetworkPage"
import { ConnectionFinderPage } from "../pages/ConnectionFinderPage"
import { NotFoundPage } from "../pages/NotFoundPage"

export const router = createBrowserRouter([
  {
    element: <AppLayout />,
    children: [
      { path: "/", element: <HomePage /> },
      { path: "/connections", element: <ConnectionFinderPage /> },
      { path: "/:username", element: <DeveloperExplorerPage /> },
      { path: "/:username/network", element: <NetworkPage /> },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
])
