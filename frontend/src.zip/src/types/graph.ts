export interface Developer {
  username: string;
  name: string | null;
  avatarUrl: string;
  bio: string | null;
  location?: string | null;
  company?: string | null;
  public_repos: number;
  followers: number;
  profile_url: string;
}

export interface Repository {
  name: string;
  fullName: string;
  ownerUsername: string;
  description: string | null;
  url: string;
  stars: number;
  forks: number;
  languages?: string[];
  topics?: string[];
}

export interface Technology {
  name: string;
  normalizedName: string;
  repoCount?: number;
  devCount?: number;
}

export interface Topic {
  name: string;
  normalizedName: string;
}

export interface Organization {
  login: string;
  name: string;
  url: string;
}

export interface GraphNode {
  id: string;
  type: string;
  label: string;
  properties: Record<string, any>;
  val?: number; // size in graph
  color?: string;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  relationship: string;
}

export interface GraphResponse {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface DeveloperProfile {
  developer: Developer;
  repositories: Repository[];
  technologies: Technology[];
  topics: Topic[];
  organizations: Organization[];
}

export interface DeveloperConnection {
  username: string;
  name: string | null;
  avatarUrl: string;
  sharedTechnologies: string[];
  sharedTopics: string[];
  sharedOrganizations: string[];
  totalConnections: number;
}

export interface ConnectionPath {
  found: boolean;
  path: {
    type: string;
    label: string;
    properties: Record<string, any>;
  }[];
  relationships: string[];
}

export interface TechnologyCommunity {
  technology: Technology;
  developers: Developer[];
  repositories: Repository[];
  relatedTechnologies: Technology[];
  topics: Topic[];
}

export interface ApiEnvelope<T> {
  success: boolean;
  message?: string;
  data: T;
  error?: {
    code: string;
    message: string;
  };
}
